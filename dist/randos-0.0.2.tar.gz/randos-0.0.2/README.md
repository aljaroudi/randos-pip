# randos-pip
An Python pip package for generating randomness
